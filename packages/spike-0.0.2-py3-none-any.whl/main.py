from spike import App

INFO = """spike-interfaces is an effort to implement python classes 
defining the interfaces available with LEGO Spike Prime python.

The goal is to allow a developer to program against these 
interfaces in the IDE of their choice.  Code can then be 
copy/pasted into the SPIKE IDE to be uploaded and executed
on the appliance. 
"""

app = App()

if __name__ == '__main__':
    app.play_sound("Zip", 50)