# spike-interfaces

```spike-interfaces``` is an effort to implement python classes 
defining the interfaces available with LEGO Spike Prime python.

The goal is to allow a developer to program against these 
interfaces in the IDE of their choice.  Code can then be 
copy/pasted into the SPIKE IDE to be uploaded and executed
on the appliance. 

### Installation
``` 
> git checkout <release>
> python -m build --wheel
> cd ./dist
> pip install spike-<release>-py3-none-any.whl
```

### Resources
* https://github.com/LEGO/MINDSTORMS-Robot-Inventor-hub-API
* https://antonsmindstorms.com/2021/01/14/advanced-undocumented-python-in-spike-prime-and-mindstorms-hubs/#exiting
